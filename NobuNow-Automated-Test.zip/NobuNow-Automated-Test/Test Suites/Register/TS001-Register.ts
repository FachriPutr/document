<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TS001-Register</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>60bd6d12-97d5-4648-a792-30b24297c8c9</testSuiteGuid>
   <testCaseLink>
      <guid>47b988a6-29fe-4d99-baa6-6ec458573ed1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/RegisterFirstDownloader/TC002-Register</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>8545d32a-79c8-4e7b-bd56-b2aa12edb3c3</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/RegisterFirstDownloader/DF001-Register</testDataId>
      </testDataLink>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>337caf5a-0ae2-4898-8a82-cfba91dde641</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>ad815af5-6552-4c8f-a9bc-39e745ae17c5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/RegisterFirstDownloader/TC002-Register</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>16625218-6687-4373-a2ed-d29d87db910f</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/RegisterFirstDownloader/DF001-Register</testDataId>
      </testDataLink>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>337caf5a-0ae2-4898-8a82-cfba91dde641</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
