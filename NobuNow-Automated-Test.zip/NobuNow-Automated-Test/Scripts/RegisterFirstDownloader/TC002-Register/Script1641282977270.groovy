import com.kms.katalon.core.testdata.ExcelData

import com.kms.katalon.core.testdata.ExcelData as ExcelData
import com.kms.katalon.core.testdata.TestData as TestData
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import groovy.ui.SystemOutputInterceptor as SystemOutputInterceptor
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import java.io.FileInputStream as FileInputStream
import java.io.FileNotFoundException as FileNotFoundException
import java.io.IOException as IOException
import java.util.Date as Date
import org.apache.poi.xssf.usermodel.XSSFCell as XSSFCell
import org.apache.poi.xssf.usermodel.XSSFRow as XSSFRow
import org.apache.poi.xssf.usermodel.XSSFSheet as XSSFSheet
import org.apache.poi.xssf.usermodel.XSSFWorkbook as XSSFWorkbook
import java.lang.String as String
import com.kms.katalon.core.testdata.InternalData as InternalData

Mobile.callTestCase(findTestCase('RegisterFirstDownloader/TC001-FlashScreen'), [:], FailureHandling.STOP_ON_FAILURE)

/*for (int i = 1; i < 20; i++) {
    String NomorHandphone     = findTestData('DF001-Register').getValue(3, i)
	String OTP			      = findTestData('DF001-Register').getValue(4, i)
	String PIn			      = findTestData('DF001-Register').getValue(5, i)
	String NamaLengkap    	  = findTestData('DF001-Register').getValue(6, i)
	String Password		  	  = findTestData('DF001-Register').getValue(7, i)
	String KonfirmasiPassword = findTestData('DF001-Register').getValue(8, i)
	

	
Mobile.setText(findTestObject('RegisterFirstDownloader/OR004-InputNomorHandphone'), findTestData('DF001-Register').getValue(3, i))

Mobile.tap(findTestObject('RegisterFirstDownloader/OR005-ButtonLanjutkan'), 0)

}

*/
TestData ExcelData = findTestData('RegisterFirstDownloader/DF002-Testing')

System.out.println('[Row Count] : ' + ExcelData.getRowNumbers())

for (int i = 1; i <= ExcelData.getRowNumbers(); i++) {
	
    Mobile.setText(findTestObject('RegisterFirstDownloader/OR004-InputNomorHandphone'), excelData.getValue(1, i) , false)

    Mobile.tap(findTestObject('RegisterFirstDownloader/OR005-ButtonLanjutkan'), 0)
}

